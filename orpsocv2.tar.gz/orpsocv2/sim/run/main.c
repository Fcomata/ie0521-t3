void main (){

int res = funcion(4,5,6,4,3,2,1);

}

int funcion(int x1, int x2, int x3, int x4, int x5, int x6, int x7){

	if(x7 > 4){return (x1+x2+x3+x4-x5-x6);}
	else{return (x1+x2+x3+x4+x5-x6);}
}
