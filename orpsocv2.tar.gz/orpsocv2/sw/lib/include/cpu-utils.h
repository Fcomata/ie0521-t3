#ifndef _CPU_UTILS_H_
#define _CPU_UTILS_H_

// Somehow in future detect which CPU we're using, but for now hardcode OR1200
#include "or1200-utils.h"

#endif
